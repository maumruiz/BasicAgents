from enum import Enum
from agents import *

class Trap(Thing):
    '''Creates a Gold as a subclass of Thing'''
    pass

class Gold(Thing):
    '''Creates a Trap as a subclass of Thing'''
    pass